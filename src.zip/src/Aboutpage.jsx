import React from 'react';

const TEAM = [
    { name: 'Arjun Mehta', role: 'Co-founder & CEO', bio: 'Former product manager at MakeMyTrip. Passionate traveller who has visited 40+ countries and all 28 Indian states.', avatar: 'AM', bg: 'linear-gradient(135deg,#1A3D5C,#2E6B9E)' },
    { name: 'Kavya Nair', role: 'Co-founder & CTO', bio: 'Ex-Google AI researcher with a PhD in NLP. Built the core Gemini integration and the itinerary parsing engine.', avatar: 'KN', bg: 'linear-gradient(135deg,#C4532A,#D97706)' },
    { name: 'Rohan Gupta', role: 'Head of Design', bio: 'Former design lead at Airbnb India. Believes that good design should feel effortless and make your next adventure feel inevitable.', avatar: 'RG', bg: 'linear-gradient(135deg,#134E5E,#71B280)' },
    { name: 'Shreya Patel', role: 'Head of Content', bio: 'Travel writer with bylines in National Geographic Traveller and Condé Nast India. Has eaten her way through 35 countries.', avatar: 'SP', bg: 'linear-gradient(135deg,#4776E6,#8E54E9)' },
];

const VALUES = [
    { icon: '🌍', title: 'Travel for everyone', desc: 'Whether you have ₹10,000 or ₹10 lakh, VoyageAI helps you make the most of your trip. Great travel is about curiosity, not budget.' },
    { icon: '⚡', title: 'Radical simplicity', desc: 'We believe planning a trip should take minutes, not days. Every feature we build is tested against: does this make planning simpler?' },
    { icon: '🔬', title: 'AI with local knowledge', desc: 'Our prompts are crafted by real travellers and locals. We don\'t just surface tourist traps — we help you find the places that matter.' },
    { icon: '🌱', title: 'Responsible travel', desc: 'We partner with sustainable tourism initiatives and encourage travellers to support local businesses, respect local cultures and minimise impact.' },
];

const MILESTONES = [
    { year: '2023', title: 'Founded', desc: 'VoyageAI was founded in Bengaluru by two former Google engineers frustrated by how hard it was to plan a good trip.' },
    { year: '2024', title: 'Gemini Integration', desc: 'Integrated with Google Gemini to power real-time itinerary generation. First 10,000 trips planned in the first month.' },
    { year: '2025', title: '50K Travellers', desc: 'Crossed 50,000 active users across India. Launched sample trip library and dashboard features.' },
    { year: '2026', title: 'Image Generation', desc: 'Added Gemini-powered place photography. Expanded destination coverage to 120+ cities worldwide.' },
];

export default function AboutPage({ setPage }) {
    return (
        <div>

            {/* HERO */}
            <section style={{ background: 'linear-gradient(135deg,#1A3D5C 0%,#0D1E2D 100%)', padding: 'clamp(60px,8vw,100px) 2rem', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
                <div style={{ position: 'absolute', inset: 0, backgroundImage: 'radial-gradient(rgba(255,255,255,.05) 1px,transparent 1px)', backgroundSize: '28px 28px' }} />
                <div style={{ position: 'relative', maxWidth: 680, margin: '0 auto' }}>
                    <div className="fade-up" style={{ display: 'inline-block', background: 'rgba(196,83,42,.2)', border: '1px solid rgba(196,83,42,.4)', color: '#E8A07A', fontSize: '.8rem', fontWeight: 700, padding: '5px 16px', borderRadius: 100, marginBottom: 24, textTransform: 'uppercase', letterSpacing: '.05em' }}>
                        Our Story
                    </div>
                    <h1 className="fade-up fade-up-d1" style={{ fontFamily: "'Playfair Display',serif", fontSize: 'clamp(2rem,5vw,3.2rem)', fontWeight: 700, color: '#fff', lineHeight: 1.15, marginBottom: 20, letterSpacing: '-.02em' }}>
                        We believe everyone deserves<br /><span style={{ color: '#E8A07A', fontStyle: 'italic' }}>an extraordinary trip</span>
                    </h1>
                    <p className="fade-up fade-up-d2" style={{ color: 'rgba(255,255,255,.65)', fontSize: '1.08rem', lineHeight: 1.75 }}>
                        VoyageAI was born from a simple frustration: planning a great trip takes too long and relies too much on luck. We're fixing that with AI.
                    </p>
                </div>
            </section>

            {/* MISSION */}
            <section style={{ maxWidth: 900, margin: '0 auto', padding: 'clamp(60px,8vw,100px) 2rem' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '3rem', alignItems: 'center' }}>
                    <div className="fade-up">
                        <div className="section-label">Our Mission</div>
                        <h2 className="section-title">Turn your travel dreams into detailed plans</h2>
                        <p style={{ color: 'var(--ink-soft)', lineHeight: 1.8, marginBottom: '1.5rem' }}>
                            We started VoyageAI because we were tired of spending more time planning trips than taking them. Hours poring over TripAdvisor reviews, cross-referencing blog posts, trying to figure out what was actually open and what had closed down — it was exhausting.
                        </p>
                        <p style={{ color: 'var(--ink-soft)', lineHeight: 1.8 }}>
                            With Gemini AI, we can now give every traveller the equivalent of a local friend who's been everywhere and knows every great restaurant, hidden viewpoint and worthwhile detour. That's VoyageAI.
                        </p>
                    </div>

                    <div className="fade-up fade-up-d2" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                        {[
                            { n: '50K+', l: 'Trips Planned' }, { n: '120+', l: 'Destinations' },
                            { n: '4.9★', l: 'App Rating' }, { n: '2min', l: 'Avg Plan Time' },
                        ].map((s, i) => (
                            <div key={i} style={{ background: i % 2 === 0 ? 'var(--sky)' : 'var(--terra)', borderRadius: 'var(--radius)', padding: '1.5rem', textAlign: 'center' }}>
                                <div style={{ fontFamily: "'Playfair Display',serif", fontSize: '1.9rem', fontWeight: 700, color: '#fff' }}>{s.n}</div>
                                <div style={{ fontSize: '.8rem', color: 'rgba(255,255,255,.75)', marginTop: 4, fontWeight: 500 }}>{s.l}</div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            <div className="divider" style={{ maxWidth: 900, margin: '0 auto' }} />

            {/* VALUES */}
            <section style={{ background: 'var(--white)', padding: 'clamp(60px,8vw,100px) 2rem' }}>
                <div style={{ maxWidth: 1000, margin: '0 auto', textAlign: 'center' }}>
                    <div className="section-label fade-up">What we stand for</div>
                    <h2 className="section-title fade-up fade-up-d1" style={{ margin: '0 auto 3rem' }}>Our values</h2>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: '1.25rem' }}>
                        {VALUES.map((v, i) => (
                            <div key={i} className={`fade-up fade-up-d${i + 1}`} style={{ background: 'var(--sand)', border: '1px solid var(--sand-dark)', borderRadius: 'var(--radius)', padding: '1.75rem', textAlign: 'left' }}>
                                <div style={{ fontSize: '2rem', marginBottom: '1rem' }}>{v.icon}</div>
                                <h3 style={{ fontFamily: "'Playfair Display',serif", fontWeight: 700, marginBottom: '.5rem', color: 'var(--ink)' }}>{v.title}</h3>
                                <p style={{ fontSize: '.87rem', color: 'var(--ink-soft)', lineHeight: 1.7 }}>{v.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* TIMELINE */}
            <section style={{ padding: 'clamp(60px,8vw,100px) 2rem' }}>
                <div style={{ maxWidth: 700, margin: '0 auto', textAlign: 'center' }}>
                    <div className="section-label fade-up">Our journey</div>
                    <h2 className="section-title fade-up fade-up-d1" style={{ margin: '0 auto 3rem' }}>How we got here</h2>
                    <div style={{ position: 'relative', paddingLeft: '2.5rem' }}>
                        <div style={{ position: 'absolute', left: 14, top: 0, bottom: 0, width: 2, background: 'var(--sand-dark)' }} />
                        {MILESTONES.map((m, i) => (
                            <div key={i} className={`fade-up fade-up-d${i + 1}`} style={{ position: 'relative', marginBottom: '2.5rem', textAlign: 'left' }}>
                                <div style={{ position: 'absolute', left: -32, top: 4, width: 16, height: 16, borderRadius: '50%', background: i % 2 === 0 ? 'var(--terra)' : 'var(--sky)', border: '3px solid var(--white)' }} />
                                <div style={{ fontSize: '.78rem', fontWeight: 700, color: 'var(--terra)', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: 4 }}>{m.year}</div>
                                <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: '1.1rem', fontWeight: 700, color: 'var(--ink)', marginBottom: 6 }}>{m.title}</h3>
                                <p style={{ fontSize: '.9rem', color: 'var(--ink-soft)', lineHeight: 1.7 }}>{m.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* TEAM */}
            <section style={{ background: 'var(--white)', padding: 'clamp(60px,8vw,100px) 2rem' }}>
                <div style={{ maxWidth: 1000, margin: '0 auto', textAlign: 'center' }}>
                    <div className="section-label fade-up">The people</div>
                    <h2 className="section-title fade-up fade-up-d1" style={{ margin: '0 auto 3rem' }}>Meet the team</h2>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: '1.5rem' }}>
                        {TEAM.map((member, i) => (
                            <div key={i} className={`fade-up fade-up-d${i + 1}`} style={{ background: 'var(--sand)', border: '1px solid var(--sand-dark)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
                                <div style={{ height: 90, background: member.bg, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                    <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'rgba(255,255,255,.2)', border: '3px solid rgba(255,255,255,.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: "'Playfair Display',serif", fontWeight: 700, fontSize: '1.4rem', color: '#fff' }}>
                                        {member.avatar}
                                    </div>
                                </div>
                                <div style={{ padding: '1.25rem' }}>
                                    <div style={{ fontFamily: "'Playfair Display',serif", fontWeight: 700, fontSize: '1rem', color: 'var(--ink)', marginBottom: 3 }}>{member.name}</div>
                                    <div style={{ fontSize: '.78rem', fontWeight: 600, color: 'var(--terra)', textTransform: 'uppercase', letterSpacing: '.04em', marginBottom: '.75rem' }}>{member.role}</div>
                                    <p style={{ fontSize: '.86rem', color: 'var(--ink-soft)', lineHeight: 1.65 }}>{member.bio}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA */}
            <section style={{ background: 'linear-gradient(135deg,var(--terra) 0%,#8B3418 100%)', padding: 'clamp(50px,7vw,90px) 2rem', textAlign: 'center' }}>
                <h2 className="fade-up" style={{ fontFamily: "'Playfair Display',serif", fontSize: 'clamp(1.8rem,4vw,2.6rem)', fontWeight: 700, color: '#fff', marginBottom: 16 }}>
                    Let's plan your next adventure
                </h2>
                <p className="fade-up fade-up-d1" style={{ color: 'rgba(255,255,255,.7)', fontSize: '1.05rem', marginBottom: 32, maxWidth: 440, margin: '0 auto 32px' }}>
                    Join 50,000+ explorers who plan smarter with VoyageAI.
                </p>
                <button className="fade-up fade-up-d2 btn btn-lg" style={{ background: '#fff', color: 'var(--terra)', fontWeight: 700 }} onClick={() => setPage('planner')}>
                    Start Planning Free →
                </button>
            </section>

        </div>
    );
}