import React from 'react';
import { Logo } from './shared.jsx';

export default function Footer({ setPage }) {
    return (
        <footer className="footer">
            <div className="footer-main">
                <div className="footer-brand">
                    <div className="footer-brand-logo">
                        <Logo size={30} />
                        <span>Voyage<em>AI</em></span>
                    </div>
                    <p>AI-powered travel planning for curious explorers. Build personalised day-by-day itineraries in seconds.</p>
                    <div className="footer-socials">
                        {['𝕏', 'in', 'f', '▶'].map((s, i) => (
                            <button key={i} className="footer-social-btn">{s}</button>
                        ))}
                    </div>
                </div>

                <div className="footer-col">
                    <h4>Explore</h4>
                    <a onClick={() => setPage('planner')}>AI Trip Planner</a>
                    <a onClick={() => setPage('trips')}>Sample Trips</a>
                    <a onClick={() => setPage('dashboard')}>My Dashboard</a>
                    <a onClick={() => setPage('about')}>About Us</a>
                </div>

                <div className="footer-col">
                    <h4>Destinations</h4>
                    <a>Rajasthan</a>
                    <a>Kerala</a>
                    <a>Kashmir</a>
                    <a>Goa</a>
                    <a>Himachal Pradesh</a>
                </div>

                <div className="footer-col">
                    <h4>Company</h4>
                    <a onClick={() => setPage('about')}>Our Story</a>
                    <a>Privacy Policy</a>
                    <a>Terms of Service</a>
                    <a>Contact Us</a>
                    <a>Careers</a>
                </div>
            </div>

            <div className="footer-bottom">
                <span>© 2026 <strong>VoyageAI</strong>. Built with React & Google Gemini.</span>
                <span>Plan smarter. Travel better. ✦</span>
            </div>
        </footer>
    );
}