import React from 'react';
import { SAMPLE_TRIPS } from './shared.jsx';

const STATS = [
    { value: '50,000+', label: 'Trips Planned' },
    { value: '120+', label: 'Destinations' },
    { value: '4.9★', label: 'User Rating' },
    { value: '2 min', label: 'Avg. Plan Time' },
];

const HOW_STEPS = [
    { icon: '📍', title: 'Choose your destination', desc: 'Enter any city, region or country. From hidden gems to iconic capitals.' },
    { icon: '⚙️', title: 'Set your preferences', desc: 'Pick your budget tier, trip duration and travel style — adventure, culture, food or relaxation.' },
    { icon: '✦', title: 'AI generates your plan', desc: 'Gemini AI crafts a detailed day-by-day itinerary with places, food, hotels and transport tips.' },
    { icon: '✈️', title: 'Pack your bags', desc: 'Save your plan, share it and travel with total confidence.' },
];

const FEATURES = [
    { icon: '🗺', title: 'Day-by-Day Itineraries', desc: 'Structured morning to evening plans for every day of your trip.' },
    { icon: '🍽', title: 'Food & Restaurant Picks', desc: 'Local specialities, iconic restaurants and street food gems for every destination.' },
    { icon: '🏨', title: 'Hotel Recommendations', desc: 'Curated stays matched to your budget — from hostels to heritage hotels.' },
    { icon: '💰', title: 'Budget Breakdowns', desc: 'Realistic cost estimates for accommodation, food, transport and activities.' },
    { icon: '🌿', title: 'Hidden Gems', desc: 'Beyond the tourist trail — off-the-beaten-path experiences the guidebooks miss.' },
    { icon: '📱', title: 'Save & Access Anywhere', desc: 'Save unlimited trips to your dashboard and access them on any device.' },
];

const TESTIMONIALS = [
    { name: 'Priya Sharma', location: 'Mumbai', text: 'Planned our 7-day Rajasthan trip in under 3 minutes. The itinerary was so detailed we barely needed to look anything up. Absolute game-changer.', avatar: 'PS', rating: 5 },
    { name: 'Rohan Mehta', location: 'Bangalore', text: 'Used VoyageAI for our Kashmir trip. The local food recommendations were spot-on and we found restaurants we\'d have never discovered otherwise.', avatar: 'RM', rating: 5 },
    { name: 'Aisha Patel', location: 'Delhi', text: 'As a solo female traveller, the safety tips and recommended neighbourhoods were incredibly helpful. Will use for every trip from now on.', avatar: 'AP', rating: 5 },
    { name: 'Vikram Nair', location: 'Kochi', text: 'The budget breakdown was realistic — we actually came in under the estimate. The offline-friendly format of the saved trips is really well thought out.', avatar: 'VN', rating: 5 },
];

export default function LandingPage({ setPage, setPreloadTrip }) {
    const featuredTrips = SAMPLE_TRIPS.slice(0, 3);

    return (
        <div style={{ overflowX: 'hidden' }}>

            {/* ── HERO ─────────────────────────────────────────────── */}
            <section style={{
                background: 'linear-gradient(135deg, #1A3D5C 0%, #0D1E2D 100%)',
                padding: 'clamp(60px,10vw,120px) 2rem clamp(80px,12vw,140px)',
                textAlign: 'center', position: 'relative', overflow: 'hidden',
            }}>
                {/* dot-grid texture */}
                <div style={{ position: 'absolute', inset: 0, backgroundImage: 'radial-gradient(rgba(255,255,255,.06) 1px,transparent 1px)', backgroundSize: '32px 32px' }} />
                {/* glow blobs */}
                <div style={{ position: 'absolute', top: '10%', left: '5%', width: 400, height: 400, borderRadius: '50%', background: 'radial-gradient(circle,rgba(196,83,42,.15) 0%,transparent 70%)', pointerEvents: 'none' }} />
                <div style={{ position: 'absolute', bottom: '5%', right: '5%', width: 500, height: 500, borderRadius: '50%', background: 'radial-gradient(circle,rgba(46,107,158,.12) 0%,transparent 70%)', pointerEvents: 'none' }} />

                <div style={{ position: 'relative', maxWidth: 740, margin: '0 auto' }}>
                    <div className="fade-up" style={{ display: 'inline-flex', alignItems: 'center', gap: 7, background: 'rgba(196,83,42,.2)', border: '1px solid rgba(196,83,42,.4)', color: '#E8A07A', fontSize: '.8rem', fontWeight: 700, padding: '5px 16px', borderRadius: 100, marginBottom: 24, textTransform: 'uppercase', letterSpacing: '.05em' }}>
                        ✦ Powered by Google Gemini AI
                    </div>

                    <h1 className="fade-up fade-up-d1" style={{ fontFamily: "'Playfair Display',serif", fontSize: 'clamp(2.4rem,6vw,4rem)', fontWeight: 900, color: '#fff', lineHeight: 1.1, marginBottom: 20, letterSpacing: '-.03em' }}>
                        Your perfect trip,<br /><span style={{ color: '#E8A07A', fontStyle: 'italic' }}>planned in seconds</span>
                    </h1>

                    <p className="fade-up fade-up-d2" style={{ color: 'rgba(255,255,255,.65)', fontSize: 'clamp(1rem,2vw,1.2rem)', lineHeight: 1.75, marginBottom: 40, maxWidth: 560, margin: '0 auto 40px' }}>
                        Tell us where you want to go. VoyageAI builds a complete day-by-day itinerary — hotels, food, attractions, transport and budget — in under 2 minutes.
                    </p>

                    <div className="fade-up fade-up-d3" style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
                        <button className="btn btn-terra btn-xl" onClick={() => setPage('planner')}>
                            ✦ Plan My Trip Free
                        </button>
                        <button className="btn btn-outline-sky btn-xl" style={{ border: '1.5px solid rgba(255,255,255,.3)', color: '#fff', background: 'transparent' }} onClick={() => setPage('trips')}>
                            Browse Sample Trips →
                        </button>
                    </div>

                    <p className="fade-up fade-up-d4" style={{ color: 'rgba(255,255,255,.35)', fontSize: '.82rem', marginTop: 20 }}>
                        No credit card required · Free forever · Powered by Gemini 2.5
                    </p>
                </div>
            </section>

            {/* ── STATS BAR ────────────────────────────────────────── */}
            <div style={{ background: 'var(--terra)', padding: '1.25rem 2rem' }}>
                <div style={{ maxWidth: 900, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '1rem', textAlign: 'center' }}>
                    {STATS.map((s, i) => (
                        <div key={i}>
                            <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 'clamp(1.4rem,3vw,1.9rem)', fontWeight: 700, color: '#fff', lineHeight: 1.1 }}>{s.value}</div>
                            <div style={{ fontSize: '.8rem', color: 'rgba(255,255,255,.75)', fontWeight: 500, marginTop: 3 }}>{s.label}</div>
                        </div>
                    ))}
                </div>
            </div>

            {/* ── HOW IT WORKS ─────────────────────────────────────── */}
            <section style={{ background: 'var(--white)', padding: 'clamp(60px,8vw,100px) 2rem' }}>
                <div style={{ maxWidth: 1000, margin: '0 auto', textAlign: 'center' }}>
                    <div className="section-label fade-up">How it works</div>
                    <h2 className="section-title fade-up fade-up-d1" style={{ margin: '0 auto 1rem' }}>From idea to itinerary in 4 steps</h2>
                    <p className="section-sub fade-up fade-up-d2" style={{ margin: '0 auto 3.5rem' }}>No sign-up required to try. Just type a destination and watch VoyageAI do the rest.</p>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))', gap: '1.5rem' }}>
                        {HOW_STEPS.map((step, i) => (
                            <div key={i} className={`fade-up fade-up-d${i + 1}`} style={{ textAlign: 'left', padding: '1.75rem', background: 'var(--sand)', borderRadius: 'var(--radius)', border: '1px solid var(--sand-dark)', position: 'relative', overflow: 'hidden' }}>
                                <div style={{ position: 'absolute', top: 16, right: 16, fontFamily: "'Playfair Display',serif", fontSize: '3rem', fontWeight: 900, color: 'rgba(196,83,42,.08)', lineHeight: 1 }}>{i + 1}</div>
                                <div style={{ fontSize: '2rem', marginBottom: '1rem' }}>{step.icon}</div>
                                <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: '1rem', fontWeight: 700, color: 'var(--ink)', marginBottom: '.5rem' }}>{step.title}</h3>
                                <p style={{ fontSize: '.88rem', color: 'var(--ink-soft)', lineHeight: 1.65 }}>{step.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* ── FEATURED TRIPS ───────────────────────────────────── */}
            <section style={{ padding: 'clamp(60px,8vw,100px) 2rem', background: 'var(--sand)' }}>
                <div style={{ maxWidth: 1060, margin: '0 auto' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '2.5rem', flexWrap: 'wrap', gap: '1rem' }}>
                        <div>
                            <div className="section-label">Ready-made trips</div>
                            <h2 className="section-title" style={{ marginBottom: 0 }}>Start with a curated itinerary</h2>
                        </div>
                        <button className="btn btn-outline-sky btn-sm" onClick={() => setPage('trips')}>View all 6 trips →</button>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))', gap: '1.5rem' }}>
                        {featuredTrips.map((trip, i) => (
                            <div key={trip.id} className={`fade-up fade-up-d${i + 1}`} style={{ background: 'var(--white)', borderRadius: 'var(--radius)', border: '1px solid var(--sand-dark)', overflow: 'hidden', transition: 'transform .2s,box-shadow .2s', cursor: 'pointer' }}
                                onClick={() => { setPreloadTrip(trip); setPage('planner'); }}
                                onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.boxShadow = 'var(--shadow-lg)'; }}
                                onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = ''; }}
                            >
                                <div style={{ height: 90, background: trip.gradient, padding: '1.25rem 1.5rem', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
                                    <div style={{ fontFamily: "'Playfair Display',serif", fontSize: '1.15rem', fontWeight: 700, color: '#fff' }}>{trip.emoji} {trip.title}</div>
                                    <div style={{ fontSize: '.78rem', color: 'rgba(255,255,255,.7)', marginTop: 3 }}>{trip.tagline}</div>
                                </div>
                                <div style={{ padding: '1.1rem 1.4rem' }}>
                                    <div style={{ display: 'flex', gap: 6, marginBottom: '.75rem', flexWrap: 'wrap' }}>
                                        <span className="badge badge-sky">{trip.days} Days</span>
                                        <span className="badge badge-terra">{trip.budget}</span>
                                    </div>
                                    <p style={{ fontSize: '.86rem', color: 'var(--ink-soft)', lineHeight: 1.6, marginBottom: '1rem' }}>{trip.preferences.slice(0, 80)}…</p>
                                    <div style={{ fontSize: '.85rem', fontWeight: 600, color: 'var(--sky-mid)' }}>Open itinerary →</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* ── FEATURES ─────────────────────────────────────────── */}
            <section style={{ background: 'var(--white)', padding: 'clamp(60px,8vw,100px) 2rem' }}>
                <div style={{ maxWidth: 1060, margin: '0 auto', textAlign: 'center' }}>
                    <div className="section-label fade-up">Everything included</div>
                    <h2 className="section-title fade-up fade-up-d1" style={{ margin: '0 auto 1rem' }}>Not just a list of attractions</h2>
                    <p className="section-sub fade-up fade-up-d2" style={{ margin: '0 auto 3.5rem' }}>Every VoyageAI itinerary includes everything you need to travel with confidence.</p>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))', gap: '1.25rem' }}>
                        {FEATURES.map((f, i) => (
                            <div key={i} className={`fade-up fade-up-d${(i % 4) + 1}`} style={{ textAlign: 'left', padding: '1.5rem', background: 'var(--sand)', borderRadius: 'var(--radius)', border: '1px solid var(--sand-dark)' }}>
                                <div style={{ fontSize: '1.8rem', marginBottom: '.85rem' }}>{f.icon}</div>
                                <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: '1rem', fontWeight: 700, color: 'var(--ink)', marginBottom: '.4rem' }}>{f.title}</h3>
                                <p style={{ fontSize: '.87rem', color: 'var(--ink-soft)', lineHeight: 1.65 }}>{f.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* ── TESTIMONIALS ─────────────────────────────────────── */}
            <section style={{ background: 'var(--sand)', padding: 'clamp(60px,8vw,100px) 2rem' }}>
                <div style={{ maxWidth: 1060, margin: '0 auto', textAlign: 'center' }}>
                    <div className="section-label fade-up">Traveller stories</div>
                    <h2 className="section-title fade-up fade-up-d1" style={{ margin: '0 auto 3rem' }}>Loved by explorers across India</h2>

                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(240px,1fr))', gap: '1.25rem' }}>
                        {TESTIMONIALS.map((t, i) => (
                            <div key={i} className={`fade-up fade-up-d${i + 1}`} style={{ background: 'var(--white)', borderRadius: 'var(--radius)', border: '1px solid var(--sand-dark)', padding: '1.5rem', textAlign: 'left' }}>
                                <div style={{ color: '#F59E0B', fontSize: '.95rem', marginBottom: '.75rem', letterSpacing: 2 }}>★★★★★</div>
                                <p style={{ fontSize: '.9rem', color: 'var(--ink-mid)', lineHeight: 1.7, marginBottom: '1.1rem', fontStyle: 'italic' }}>"{t.text}"</p>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                                    <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--sky)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: '.85rem', flexShrink: 0 }}>{t.avatar}</div>
                                    <div>
                                        <div style={{ fontWeight: 600, fontSize: '.88rem', color: 'var(--ink)' }}>{t.name}</div>
                                        <div style={{ fontSize: '.78rem', color: 'var(--ink-soft)' }}>{t.location}</div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* ── CTA BANNER ───────────────────────────────────────── */}
            <section style={{ background: 'linear-gradient(135deg,var(--sky) 0%,#0D1E2D 100%)', padding: 'clamp(60px,8vw,100px) 2rem', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
                <div style={{ position: 'absolute', inset: 0, backgroundImage: 'radial-gradient(rgba(255,255,255,.04) 1px,transparent 1px)', backgroundSize: '28px 28px' }} />
                <div style={{ position: 'relative', maxWidth: 620, margin: '0 auto' }}>
                    <h2 className="fade-up" style={{ fontFamily: "'Playfair Display',serif", fontSize: 'clamp(1.8rem,4vw,2.8rem)', fontWeight: 700, color: '#fff', marginBottom: 16, letterSpacing: '-.02em' }}>
                        Ready to plan your next adventure?
                    </h2>
                    <p className="fade-up fade-up-d1" style={{ color: 'rgba(255,255,255,.6)', fontSize: '1.05rem', lineHeight: 1.7, marginBottom: 36 }}>
                        Join 50,000+ travellers who plan smarter with VoyageAI. Free to start, no credit card required.
                    </p>
                    <div className="fade-up fade-up-d2" style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
                        <button className="btn btn-terra btn-lg" onClick={() => setPage('planner')}>Start Planning Free →</button>
                        <button className="btn btn-sm" style={{ background: 'rgba(255,255,255,.1)', color: '#fff', border: '1.5px solid rgba(255,255,255,.2)', padding: '11px 26px', borderRadius: 8, fontSize: '.95rem' }} onClick={() => setPage('about')}>Learn about us</button>
                    </div>
                </div>
            </section>

        </div>
    );
}