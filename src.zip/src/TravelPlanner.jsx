import React, { useState, useEffect, useRef } from 'react';

// ─────────────────────────────────────────────────────────────
// GLOBAL CSS
// ─────────────────────────────────────────────────────────────
const GLOBAL_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=DM+Sans:wght@300;400;500;600&display=swap');

  :root {
    --terra:#C4532A; --terra-light:#F0E8E2; --terra-mid:#E8A07A;
    --sky:#1A3D5C; --sky-mid:#2E6B9E; --sky-light:#EAF2FA;
    --sand:#F7F2EC; --sand-dark:#E8DDD0;
    --ink:#1C1917; --ink-mid:#44403C; --ink-soft:#78716C;
    --white:#FEFCF9; --gold:#D97706; --gold-light:#FEF3C7;
    --success:#15803D; --success-light:#DCFCE7;
    --radius:16px; --radius-sm:8px;
  }
  *{box-sizing:border-box;margin:0;padding:0;}
  body,#root{font-family:'DM Sans',sans-serif;background:var(--sand);color:var(--ink);}

  @keyframes fadeUp{from{opacity:0;transform:translateY(14px);}to{opacity:1;transform:translateY(0);}}
  @keyframes shimmer{0%{background-position:-600px 0;}100%{background-position:600px 0;}}
  @keyframes spin{to{transform:rotate(360deg);}}
  @keyframes imgAppear{from{opacity:0;}to{opacity:1;}}

  .fade-up{animation:fadeUp .45s ease both;}
  .fade-up-d1{animation-delay:.08s;}.fade-up-d2{animation-delay:.16s;}
  .fade-up-d3{animation-delay:.24s;}.fade-up-d4{animation-delay:.32s;}

  /* NAV */
  .tp-nav{position:sticky;top:0;z-index:100;background:var(--sky);padding:0 2rem;display:flex;align-items:center;justify-content:space-between;height:60px;box-shadow:0 2px 16px rgba(26,61,92,.18);}
  .tp-logo{display:flex;align-items:center;gap:10px;cursor:pointer;background:none;border:none;}
  .tp-logo-text{font-family:'Playfair Display',serif;font-weight:700;font-size:1.25rem;color:var(--white);letter-spacing:-.01em;}
  .tp-logo-text span{color:var(--terra-mid);}
  .tp-nav-links{display:flex;align-items:center;gap:6px;flex-wrap:wrap;}
  .tp-nav-link{background:none;border:none;cursor:pointer;font-family:'DM Sans',sans-serif;font-size:.875rem;font-weight:500;color:rgba(255,255,255,.7);padding:6px 14px;border-radius:8px;transition:background .2s,color .2s;}
  .tp-nav-link:hover{background:rgba(255,255,255,.1);color:#fff;}
  .tp-nav-link.active{background:rgba(255,255,255,.15);color:#fff;}
  .tp-btn-outline{background:transparent;border:1.5px solid rgba(255,255,255,.4);color:#fff;cursor:pointer;font-family:'DM Sans',sans-serif;font-size:.875rem;font-weight:500;padding:6px 16px;border-radius:8px;transition:border-color .2s,background .2s;}
  .tp-btn-outline:hover{border-color:#fff;background:rgba(255,255,255,.08);}
  .tp-btn-primary{background:var(--terra);border:none;color:#fff;cursor:pointer;font-family:'DM Sans',sans-serif;font-size:.875rem;font-weight:600;padding:7px 18px;border-radius:8px;transition:background .2s,transform .15s;}
  .tp-btn-primary:hover{background:#B34520;transform:translateY(-1px);}

  /* HERO */
  .tp-hero{background:linear-gradient(135deg,var(--sky) 0%,#0E2A42 100%);padding:64px 2rem 80px;text-align:center;position:relative;overflow:hidden;}
  .tp-hero::before{content:'';position:absolute;inset:0;background:url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");}
  .tp-hero-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(196,83,42,.25);border:1px solid rgba(196,83,42,.5);color:var(--terra-mid);font-size:.8rem;font-weight:600;padding:5px 14px;border-radius:100px;margin-bottom:20px;letter-spacing:.03em;text-transform:uppercase;}
  .tp-hero h1{font-family:'Playfair Display',serif;font-size:clamp(2rem,5vw,3.2rem);font-weight:700;color:#fff;line-height:1.15;margin-bottom:16px;letter-spacing:-.02em;}
  .tp-hero h1 em{color:var(--terra-mid);font-style:normal;}
  .tp-hero p{color:rgba(255,255,255,.65);font-size:1.1rem;max-width:520px;margin:0 auto;line-height:1.7;}

  /* LAYOUT */
  .tp-main{max-width:1000px;margin:0 auto;padding:2.5rem 1.5rem 4rem;}

  /* CARD */
  .tp-card{background:var(--white);border-radius:var(--radius);border:1px solid var(--sand-dark);padding:2rem;}
  .tp-card-header{display:flex;align-items:center;gap:10px;margin-bottom:1.5rem;padding-bottom:1rem;border-bottom:1px solid var(--sand-dark);}
  .tp-card-icon{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;}
  .tp-card-icon.terra{background:var(--terra-light);}
  .tp-card-icon.sky{background:var(--sky-light);}
  .tp-card-title{font-family:'Playfair Display',serif;font-size:1.15rem;font-weight:700;color:var(--ink);}

  /* SETTINGS — horizontal compact row */
  .tp-settings-row{display:grid;grid-template-columns:2.2fr 1.1fr 0.7fr auto;gap:1rem;align-items:end;margin-bottom:.75rem;}
  .tp-label{display:block;font-size:.78rem;font-weight:600;color:var(--ink-soft);text-transform:uppercase;letter-spacing:.05em;margin-bottom:5px;}
  .tp-input,.tp-select,.tp-textarea{width:100%;font-family:'DM Sans',sans-serif;font-size:.95rem;color:var(--ink);background:var(--sand);border:1.5px solid var(--sand-dark);border-radius:var(--radius-sm);padding:10px 14px;outline:none;transition:border-color .2s,background .2s;-webkit-appearance:none;}
  .tp-input:focus,.tp-select:focus,.tp-textarea:focus{border-color:var(--sky-mid);background:#fff;}
  .tp-input-icon-wrap{position:relative;}
  .tp-input-icon-wrap .tp-input{padding-left:36px;}
  .tp-input-icon{position:absolute;left:11px;top:50%;transform:translateY(-50%);font-size:15px;color:var(--ink-soft);pointer-events:none;}
  .tp-row2{display:grid;grid-template-columns:1fr auto;gap:1rem;align-items:end;margin-top:.75rem;}
  .tp-field{margin-bottom:0;}
  .tp-tag-btn{background:none;border:1.5px solid var(--terra);color:var(--terra);font-family:'DM Sans',sans-serif;font-size:.79rem;font-weight:600;padding:4px 11px;border-radius:100px;cursor:pointer;transition:background .2s,color .2s;white-space:nowrap;}
  .tp-tag-btn:hover{background:var(--terra);color:#fff;}
  .tp-generate-btn{padding:11px 24px;background:var(--sky);border:none;color:#fff;font-family:'DM Sans',sans-serif;font-size:.95rem;font-weight:600;border-radius:var(--radius-sm);cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:background .2s,transform .15s,box-shadow .2s;box-shadow:0 4px 14px rgba(26,61,92,.22);white-space:nowrap;height:44px;}
  .tp-generate-btn:hover:not(:disabled){background:#0E2A42;transform:translateY(-2px);}
  .tp-generate-btn:disabled{opacity:.6;cursor:not-allowed;transform:none;}
  .tp-save-btn{display:inline-flex;align-items:center;gap:6px;padding:9px 22px;background:transparent;border:1.5px solid var(--success);color:var(--success);font-family:'DM Sans',sans-serif;font-size:.9rem;font-weight:600;border-radius:var(--radius-sm);cursor:pointer;transition:background .2s,color .2s;margin-top:.75rem;}
  .tp-save-btn:hover{background:var(--success);color:#fff;}

  /* OUTPUT PANEL — full width below settings */
  .tp-output-panel{margin-top:1.5rem;}
  .tp-output-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:260px;color:var(--ink-soft);text-align:center;padding:2rem;}
  .tp-output-empty-icon{font-size:2.8rem;margin-bottom:1rem;opacity:.35;}

  /* OVERVIEW STRIP */
  .tp-overview{background:var(--sky-light);border-radius:12px;padding:1rem 1.25rem;margin-bottom:1.5rem;border-left:4px solid var(--sky-mid);}
  .tp-overview p{font-size:.9rem;color:var(--ink-mid);line-height:1.65;margin-bottom:4px;}
  .tp-overview p:last-child{margin-bottom:0;}

  /* BUDGET CARD */
  .tp-budget-card{background:linear-gradient(135deg,var(--sky) 0%,#0E2A42 100%);border-radius:var(--radius);padding:1.25rem 1.5rem;margin-bottom:1.5rem;color:#fff;}
  .tp-budget-card h4{font-family:'Playfair Display',serif;font-size:1rem;font-weight:700;margin-bottom:.75rem;color:var(--terra-mid);}
  .tp-budget-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:.5rem;}
  .tp-budget-item{background:rgba(255,255,255,.08);border-radius:8px;padding:.5rem .75rem;}
  .tp-budget-item-label{font-size:.75rem;color:rgba(255,255,255,.6);margin-bottom:2px;}
  .tp-budget-item-value{font-size:.9rem;font-weight:600;color:#fff;}

  /* DAY SECTION */
  .tp-day-section{margin-bottom:2rem;}
  .tp-day-header{display:flex;align-items:center;gap:10px;margin-bottom:1.25rem;}
  .tp-day-pill{background:var(--sky);color:#fff;font-family:'Playfair Display',serif;font-size:.95rem;font-weight:700;padding:5px 18px;border-radius:100px;white-space:nowrap;}
  .tp-day-theme{font-size:.9rem;color:var(--ink-soft);font-style:italic;}
  .tp-day-header-line{flex:1;height:1px;background:var(--sand-dark);}

  /* PLACE CARDS GRID */
  .tp-places-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:1rem;}

  /* PLACE CARD */
  .tp-place-card{background:var(--white);border:1px solid var(--sand-dark);border-radius:var(--radius);overflow:hidden;transition:transform .2s,box-shadow .2s;display:flex;flex-direction:column;}
  .tp-place-card:hover{transform:translateY(-3px);box-shadow:0 8px 28px rgba(26,61,92,.1);}

  /* IMAGE */
  .tp-place-img-wrap{position:relative;height:170px;overflow:hidden;background:var(--sand-dark);flex-shrink:0;}
  .tp-place-img{width:100%;height:100%;object-fit:cover;display:block;animation:imgAppear .4s ease;}
  .tp-place-img-placeholder{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:3rem;background:linear-gradient(135deg,var(--sand-dark) 0%,var(--sand) 100%);}
  .tp-place-img-skeleton{width:100%;height:100%;background:linear-gradient(90deg,var(--sand-dark) 25%,var(--sand) 50%,var(--sand-dark) 75%);background-size:600px 100%;animation:shimmer 1.4s infinite;}
  .tp-place-time-badge{position:absolute;top:10px;left:10px;background:rgba(26,61,92,.85);backdrop-filter:blur(4px);color:#fff;font-size:.72rem;font-weight:700;padding:3px 10px;border-radius:100px;text-transform:uppercase;letter-spacing:.04em;}

  /* PLACE BODY */
  .tp-place-body{padding:1rem 1.1rem 1.1rem;flex:1;display:flex;flex-direction:column;}
  .tp-place-title-row{display:flex;align-items:flex-start;gap:7px;margin-bottom:6px;}
  .tp-place-emoji{font-size:1.1rem;flex-shrink:0;margin-top:1px;}
  .tp-place-title{font-family:'Playfair Display',serif;font-size:1rem;font-weight:700;color:var(--ink);line-height:1.3;}
  .tp-place-desc{font-size:.86rem;color:var(--ink-mid);line-height:1.65;flex:1;margin-bottom:.75rem;}
  .tp-place-tags{display:flex;flex-wrap:wrap;gap:5px;margin-top:auto;}
  .tp-place-tag{font-size:.72rem;font-weight:600;padding:3px 9px;border-radius:100px;}
  .tp-place-tag.food{background:var(--terra-light);color:var(--terra);}
  .tp-place-tag.hotel{background:var(--gold-light);color:var(--gold);}
  .tp-place-tag.tip{background:var(--success-light);color:var(--success);}
  .tp-place-tag.sight{background:var(--sky-light);color:var(--sky-mid);}

  /* LOADING */
  .tp-loading{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:280px;gap:1.5rem;}
  .tp-spinner{width:44px;height:44px;border-radius:50%;border:3px solid var(--sand-dark);border-top-color:var(--sky-mid);animation:spin .9s linear infinite;}
  .tp-shimmer-line{background:linear-gradient(90deg,var(--sand-dark) 25%,var(--sand) 50%,var(--sand-dark) 75%);background-size:600px 100%;animation:shimmer 1.4s infinite;border-radius:6px;height:14px;margin-bottom:10px;}

  /* ERROR */
  .tp-error{background:#FEF2F2;border:1px solid #FECACA;border-radius:var(--radius-sm);padding:12px 16px;color:#991B1B;font-size:.9rem;margin-bottom:1rem;display:flex;gap:8px;align-items:flex-start;}

  /* READY BADGE */
  .tp-ready-badge{display:inline-flex;align-items:center;gap:5px;background:var(--success-light);color:var(--success);font-size:.78rem;font-weight:600;padding:4px 12px;border-radius:100px;border:1px solid rgba(21,128,61,.2);}

  /* AUTH */
  .tp-auth-wrap{min-height:calc(100vh - 60px);display:flex;align-items:center;justify-content:center;padding:2rem;background:radial-gradient(ellipse at 60% 40%,var(--sky-light) 0%,var(--sand) 70%);}
  .tp-auth-card{background:var(--white);border-radius:20px;border:1px solid var(--sand-dark);padding:2.5rem;width:100%;max-width:420px;box-shadow:0 20px 60px rgba(26,61,92,.1);}
  .tp-auth-logo-wrap{display:flex;align-items:center;justify-content:center;margin-bottom:1.75rem;}
  .tp-auth-title{font-family:'Playfair Display',serif;font-size:1.6rem;font-weight:700;color:var(--ink);text-align:center;margin-bottom:6px;}
  .tp-auth-sub{text-align:center;font-size:.9rem;color:var(--ink-soft);margin-bottom:2rem;}
  .tp-auth-btn{width:100%;padding:13px;background:var(--sky);border:none;color:#fff;font-family:'DM Sans',sans-serif;font-size:1rem;font-weight:600;border-radius:var(--radius-sm);cursor:pointer;transition:background .2s,transform .15s;box-shadow:0 4px 14px rgba(26,61,92,.2);}
  .tp-auth-btn:hover{background:#0E2A42;transform:translateY(-1px);}
  .tp-auth-btn.terra{background:var(--terra);}
  .tp-auth-btn.terra:hover{background:#B34520;}
  .tp-auth-link{color:var(--sky-mid);font-weight:600;cursor:pointer;}
  .tp-auth-link:hover{text-decoration:underline;}
  .tp-auth-field{margin-bottom:1.1rem;}

  /* DASHBOARD */
  .tp-dash-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:2rem;flex-wrap:wrap;gap:1rem;}
  .tp-stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:2.5rem;}
  .tp-stat-card{background:var(--white);border-radius:var(--radius);border:1px solid var(--sand-dark);padding:1.25rem 1.5rem;position:relative;overflow:hidden;}
  .tp-stat-card::before{content:'';position:absolute;left:0;top:0;bottom:0;width:4px;border-radius:4px 0 0 4px;}
  .tp-stat-card.c1::before{background:var(--sky-mid);}
  .tp-stat-card.c2::before{background:var(--success);}
  .tp-stat-card.c3::before{background:var(--gold);}
  .tp-stat-card.c4::before{background:var(--terra);}
  .tp-stat-label{font-size:.75rem;font-weight:600;color:var(--ink-soft);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px;}
  .tp-stat-value{font-family:'Playfair Display',serif;font-size:2rem;font-weight:700;color:var(--ink);line-height:1;}
  .tp-trip-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1.5rem;}
  .tp-trip-card{background:var(--white);border-radius:var(--radius);border:1px solid var(--sand-dark);overflow:hidden;transition:transform .2s,box-shadow .2s;}
  .tp-trip-card:hover{transform:translateY(-3px);box-shadow:0 12px 32px rgba(26,61,92,.12);}
  .tp-trip-banner{height:80px;padding:1.25rem 1.5rem;display:flex;align-items:flex-end;justify-content:space-between;}
  .tp-trip-banner-title{font-family:'Playfair Display',serif;font-weight:700;font-size:1.1rem;color:#fff;}
  .tp-trip-badge{background:rgba(255,255,255,.25);color:#fff;font-size:.75rem;font-weight:600;padding:3px 10px;border-radius:100px;border:1px solid rgba(255,255,255,.3);}
  .tp-trip-body{padding:1.25rem 1.5rem;}
  .tp-trip-meta{font-size:.82rem;color:var(--ink-soft);margin-bottom:8px;}
  .tp-trip-desc{font-size:.88rem;color:var(--ink-mid);line-height:1.6;margin-bottom:1rem;}
  .tp-trip-open-btn{width:100%;padding:9px;background:transparent;border:1.5px solid var(--sky-mid);color:var(--sky-mid);font-family:'DM Sans',sans-serif;font-size:.88rem;font-weight:600;border-radius:var(--radius-sm);cursor:pointer;transition:background .2s,color .2s;}
  .tp-trip-open-btn:hover{background:var(--sky-mid);color:#fff;}
  .tp-trip-del-btn{width:100%;padding:7px;background:transparent;border:1.5px solid #FECACA;color:#991B1B;font-family:'DM Sans',sans-serif;font-size:.82rem;font-weight:600;border-radius:var(--radius-sm);cursor:pointer;margin-top:6px;transition:background .2s;}
  .tp-trip-del-btn:hover{background:#FEF2F2;}

  /* FOOTER */
  .tp-footer{text-align:center;padding:1.5rem 1rem;border-top:1px solid var(--sand-dark);background:var(--white);font-size:.82rem;color:var(--ink-soft);margin-top:auto;}
  .tp-footer strong{color:var(--terra);}

  @media(max-width:800px){
    .tp-settings-row{grid-template-columns:1fr 1fr;}
    .tp-places-grid{grid-template-columns:repeat(auto-fill,minmax(240px,1fr));}
    .tp-stat-grid{grid-template-columns:repeat(2,1fr);}
  }
  @media(max-width:560px){
    .tp-settings-row{grid-template-columns:1fr;}
    .tp-places-grid{grid-template-columns:1fr 1fr;}
    .tp-main{padding:1.25rem 1rem 3rem;}
    .tp-card{padding:1.25rem;}
    .tp-nav{padding:0 1rem;}
    .tp-hero{padding:40px 1rem 56px;}
  }
  @media(max-width:400px){
    .tp-places-grid{grid-template-columns:1fr;}
  }
`;

// ─────────────────────────────────────────────────────────────
// LOGO
// ─────────────────────────────────────────────────────────────
function VoyageAILogo({ size = 34 }) {
    return (
        <svg width={size} height={size} viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="34" height="34" rx="10" fill="#C4532A" />
            <path d="M17 7L22 14H12L17 7Z" fill="white" fillOpacity="0.9" />
            <circle cx="17" cy="20" r="5" fill="white" fillOpacity="0.9" />
            <path d="M8 27C10 23 14 21 17 21C20 21 24 23 26 27" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeOpacity="0.6" />
        </svg>
    );
}

// ─────────────────────────────────────────────────────────────
// IMAGE — Generated by Gemini imagen (base64, no external fetch)
// ─────────────────────────────────────────────────────────────
const IMG_CACHE = {};

async function generateImageViaGemini(placeName, destination) {
    const { GoogleGenAI } = await import('@google/genai');
    const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY });

    const prompt = `A beautiful, vibrant travel photograph of ${placeName} in ${destination}. High quality, realistic, well-lit, tourism photography style. No text, no watermarks.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.0-flash-preview-image-generation',
        contents: prompt,
        config: {
            responseModalities: ['TEXT', 'IMAGE'],
        },
    });

    // Extract the base64 image from the response
    for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData?.data) {
            const mime = part.inlineData.mimeType || 'image/png';
            return `data:${mime};base64,${part.inlineData.data}`;
        }
    }
    return null;
}

function PlaceImage({ placeName, destination, emoji }) {
    const [imgUrl, setImgUrl] = useState(null);
    const [status, setStatus] = useState('loading');

    useEffect(() => {
        let cancelled = false;
        const cacheKey = `${placeName}__${destination}`;

        if (IMG_CACHE[cacheKey] !== undefined) {
            const cached = IMG_CACHE[cacheKey];
            setImgUrl(cached || null);
            setStatus(cached ? 'loaded' : 'failed');
            return;
        }

        setStatus('loading');

        generateImageViaGemini(placeName, destination)
            .then(dataUrl => {
                if (cancelled) return;
                IMG_CACHE[cacheKey] = dataUrl || '';
                setImgUrl(dataUrl || null);
                setStatus(dataUrl ? 'loaded' : 'failed');
            })
            .catch(() => {
                if (cancelled) return;
                IMG_CACHE[cacheKey] = '';
                setStatus('failed');
            });

        return () => { cancelled = true; };
    }, [placeName, destination]);

    return (
        <div className="tp-place-img-wrap">
            {status === 'loading' && <div className="tp-place-img-skeleton" />}
            {status === 'failed' && <div className="tp-place-img-placeholder">{emoji || '📍'}</div>}
            {status === 'loaded' && imgUrl && (
                <img
                    className="tp-place-img"
                    src={imgUrl}
                    alt={placeName}
                    onError={() => { IMG_CACHE[`${placeName}__${destination}`] = ''; setStatus('failed'); }}
                />
            )}
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// MARKDOWN PARSER
// ─────────────────────────────────────────────────────────────
function parseItinerary(raw) {
    const lines = raw.split('\n');
    const days = [], overview = [], budgetLines = [];
    let currentDay = null, currentPlace = null, inBudget = false;

    const flush = () => { if (currentPlace && currentDay) { currentDay.places.push(currentPlace); currentPlace = null; } };

    const TIME_WORDS = ['morning', 'afternoon', 'evening', 'night', 'lunch', 'dinner', 'breakfast', 'dusk', 'dawn'];
    const detectTime = t => { const l = t.toLowerCase(); for (const w of TIME_WORDS) if (l.includes(w)) return w.charAt(0).toUpperCase() + w.slice(1); return null; };

    const detectTags = text => {
        const t = text.toLowerCase(), tags = [];
        if (/food|eat|cuisine|restaurant|café|cafe|dhaba|seafood|snack|meal|dish|taste|thali|chai|street food/.test(t)) tags.push({ label: '🍽 Food', type: 'food' });
        if (/hotel|stay|resort|hostel|accommodation|check.in|lodge|guesthouse/.test(t)) tags.push({ label: '🏨 Stay', type: 'hotel' });
        if (/tip|note|remember|carry|avoid|best time|recommend|bring/.test(t)) tags.push({ label: '💡 Tip', type: 'tip' });
        if (!tags.length) tags.push({ label: '🗺 Sightseeing', type: 'sight' });
        return tags;
    };

    const getEmoji = title => {
        const t = (title || '').toLowerCase();
        if (/beach|coast|sea/.test(t)) return '🏖';
        if (/temple|mandir|shrine|church|mosque|masjid/.test(t)) return '🛕';
        if (/forest|jungle|safari|wildlife|national park/.test(t)) return '🌿';
        if (/hotel|resort|stay|hostel|guesthouse/.test(t)) return '🏨';
        if (/food|restaurant|café|market|bazaar|dhaba/.test(t)) return '🍽';
        if (/fort|palace|monument|heritage|museum/.test(t)) return '🏰';
        if (/airport|railway|station|bus|transport/.test(t)) return '🚌';
        if (/mountain|hill|trek/.test(t)) return '⛰';
        if (/lake|river|waterfall/.test(t)) return '💧';
        if (/sunset|sunrise|view|point/.test(t)) return '🌅';
        return '📍';
    };

    for (const rawLine of lines) {
        const line = rawLine.trim();
        if (!line) continue;

        // Budget section trigger
        if (/budget breakdown|approximate budget|budget summary/i.test(line)) {
            flush(); inBudget = true; continue;
        }

        // Day heading: ## Day 1 ... or **Day 1** or Day 1:
        const dayMatch = line.match(/^#{1,3}\s*(day\s*\d+[:\-–\s]*.*?)$/i) ||
            line.match(/^\*\*(day\s*\d+[^*]*)\*\*\s*$/i) ||
            line.match(/^(day\s*\d+\s*[:–\-].+)$/i);
        if (dayMatch) {
            flush(); inBudget = false;
            if (currentDay) days.push(currentDay);
            const raw = dayMatch[1].replace(/^#+\s*/, '').replace(/\*\*/g, '').trim();
            // Split "Day 1: Theme" into day number and theme
            const colonIdx = raw.search(/[:\-–]/);
            const dayNum = colonIdx > -1 ? raw.slice(0, colonIdx).trim() : raw;
            const theme = colonIdx > -1 ? raw.slice(colonIdx + 1).trim() : '';
            currentDay = { dayNum, theme, places: [] };
            currentPlace = null;
            continue;
        }

        // Place heading: ### or ** bold line
        const placeMatch = line.match(/^#{2,4}\s+(.+)$/) ||
            line.match(/^\*\*([^*]{4,70})\*\*\s*$/) ||
            line.match(/^[-*]\s+\*\*([^*]{4,70})\*\*\s*[:–]?\s*(.*)$/);

        if (placeMatch && currentDay && !inBudget) {
            flush();
            const rawTitle = (placeMatch[1] || '').replace(/^#+\s*/, '').replace(/\*\*/g, '').trim();
            if (/^day\s*\d+/i.test(rawTitle)) continue;
            const extraText = (placeMatch[2] || '').replace(/\*\*/g, '');
            currentPlace = {
                title: rawTitle,
                time: detectTime(rawTitle) || detectTime(extraText),
                desc: extraText || '',
                tags: detectTags(rawTitle + ' ' + extraText),
                emoji: getEmoji(rawTitle),
            };
            continue;
        }

        // Budget items
        if (inBudget) {
            const clean = line.replace(/^[-*•]\s*/, '').replace(/\*\*/g, '').trim();
            if (clean.length > 2) budgetLines.push(clean);
            continue;
        }

        // Bullet under place
        if (currentPlace && currentDay) {
            const clean = line.replace(/^[-*•]\s*/, '').replace(/\*\*/g, '').trim();
            if (clean) {
                currentPlace.desc += (currentPlace.desc ? '\n' : '') + clean;
                detectTags(clean).forEach(t => { if (!currentPlace.tags.find(x => x.label === t.label)) currentPlace.tags.push(t); });
                if (!currentPlace.time) currentPlace.time = detectTime(clean);
            }
            continue;
        }

        // Pre-day overview text
        if (!currentDay && !inBudget) {
            const clean = line.replace(/^#+\s*/, '').replace(/\*\*/g, '').replace(/^[-*•]\s*/, '').trim();
            if (clean.length > 3) overview.push(clean);
        }
    }

    flush();
    if (currentDay) days.push(currentDay);
    return { overview, budgetLines, days };
}

// Budget line parser
function parseBudgetLine(line) {
    const sep = line.search(/[:–\-]/);
    if (sep < 0) return { label: line, value: '' };
    return { label: line.slice(0, sep).trim(), value: line.slice(sep + 1).trim() };
}

// ─────────────────────────────────────────────────────────────
// ITINERARY DISPLAY
// ─────────────────────────────────────────────────────────────
function ItineraryDisplay({ raw, destination }) {
    const { overview, budgetLines, days } = parseItinerary(raw);

    return (
        <div className="fade-up">
            {overview.length > 0 && (
                <div className="tp-overview" style={{ marginBottom: '1.5rem' }}>
                    {overview.slice(0, 4).map((line, i) => <p key={i}>{line}</p>)}
                </div>
            )}

            {days.length === 0 && (
                <div style={{ whiteSpace: 'pre-line', fontSize: '.9rem', color: 'var(--ink-mid)', lineHeight: 1.75, padding: '1rem', background: 'var(--white)', borderRadius: 12, border: '1px solid var(--sand-dark)' }}>
                    {raw.replace(/\*\*/g, '').replace(/^#{1,4}\s*/gm, '')}
                </div>
            )}

            {days.map((day, di) => (
                <div className="tp-day-section" key={di}>
                    <div className="tp-day-header">
                        <span className="tp-day-pill">📅 {day.dayNum}</span>
                        {day.theme && <span className="tp-day-theme">{day.theme}</span>}
                        <div className="tp-day-header-line" />
                    </div>

                    {day.places.length === 0 ? (
                        <p style={{ fontSize: '.88rem', color: 'var(--ink-soft)', paddingLeft: 4 }}>No stops listed for this day.</p>
                    ) : (
                        <div className="tp-places-grid">
                            {day.places.map((place, pi) => (
                                <div className="tp-place-card" key={pi}>
                                    <PlaceImage placeName={place.title} destination={destination} emoji={place.emoji} />
                                    {place.time && (
                                        <div style={{ position: 'relative' }}>
                                            <span className="tp-place-time-badge" style={{ position: 'absolute', top: -32, left: 10 }}>{place.time}</span>
                                        </div>
                                    )}
                                    <div className="tp-place-body">
                                        <div className="tp-place-title-row">
                                            <span className="tp-place-emoji">{place.emoji}</span>
                                            <span className="tp-place-title">{place.title}</span>
                                        </div>
                                        {place.desc && (
                                            <div className="tp-place-desc">
                                                {place.desc.split('\n').slice(0, 3).map((l, li) => (
                                                    <p key={li} style={{ marginBottom: li < 2 ? 4 : 0 }}>{l}</p>
                                                ))}
                                            </div>
                                        )}
                                        {place.tags.length > 0 && (
                                            <div className="tp-place-tags">
                                                {place.tags.slice(0, 3).map((t, ti) => (
                                                    <span key={ti} className={`tp-place-tag ${t.type}`}>{t.label}</span>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            ))}

            {budgetLines.length > 0 && (
                <div className="tp-budget-card" style={{ marginTop: '1rem' }}>
                    <h4>💰 Budget Breakdown</h4>
                    <div className="tp-budget-grid">
                        {budgetLines.slice(0, 10).map((line, i) => {
                            const { label, value } = parseBudgetLine(line);
                            return (
                                <div className="tp-budget-item" key={i}>
                                    <div className="tp-budget-item-label">{label}</div>
                                    <div className="tp-budget-item-value">{value || '—'}</div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}
        </div>
    );
}

// ─────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────
const GRADIENTS = [
    'linear-gradient(135deg,#1d2671 0%,#C33764 100%)',
    'linear-gradient(135deg,#11998e 0%,#38ef7d 100%)',
    'linear-gradient(135deg,#C4532A 0%,#D97706 100%)',
    'linear-gradient(135deg,#1A3D5C 0%,#2E6B9E 100%)',
    'linear-gradient(135deg,#434343 0%,#6b6b6b 100%)',
];

export default function TravelPlanner() {
    const [currentPage, setCurrentPage] = useState('home');
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [userEmail, setUserEmail] = useState('');
    const [userName, setUserName] = useState('');
    // Use refs so values are always current at submit time (no stale-state issue)
    const loginEmailRef = useRef('');
    const signupNameRef = useRef('');

    const [destination, setDestination] = useState('');
    const [budgetType, setBudgetType] = useState('Budget');
    const [customBudget, setCustomBudget] = useState('');
    const [days, setDays] = useState('3');
    const [preferences, setPreferences] = useState('');

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [itinerary, setItinerary] = useState('');
    const [itinDestination, setItinDestination] = useState('');

    const [savedTrips, setSavedTrips] = useState(() => {
        try { return JSON.parse(localStorage.getItem('voyageai_trips') || '[]'); } catch { return []; }
    });

    const outputRef = useRef(null);

    useEffect(() => {
        const id = 'tp-global-style';
        if (!document.getElementById(id)) {
            const el = document.createElement('style');
            el.id = id; el.textContent = GLOBAL_CSS;
            document.head.appendChild(el);
        }
    }, []);

    useEffect(() => {
        try { localStorage.setItem('voyageai_trips', JSON.stringify(savedTrips)); } catch { }
    }, [savedTrips]);

    const effectiveBudget = budgetType === 'Custom'
        ? `Custom budget: ${customBudget || 'flexible'}`
        : budgetType;

    const handleSetGujaratiCulture = () => {
        setPreferences("Include authentic Gujarati food, Jungle Safari, and the local's traditional dance experiences.");
    };

    const handleAuthSubmit = (e, type) => {
        e.preventDefault();
        if (type === 'signup') {
            const first = signupNameRef.current.trim().split(/\s+/)[0] || 'Explorer';
            setUserName(first.charAt(0).toUpperCase() + first.slice(1));
        } else {
            // Extract first name from email: "john.doe@gmail.com" → "John"
            const raw = loginEmailRef.current.split('@')[0].split(/[._\-+]/)[0];
            const first = raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase();
            setUserName(first || 'Explorer');
        }
        setIsLoggedIn(true);
        setCurrentPage('dashboard');
    };
    const handleLogout = () => { setIsLoggedIn(false); setUserEmail(''); setUserName(''); setCurrentPage('home'); setItinerary(''); };

    const saveTrip = () => {
        if (!itinerary || !destination) return;
        const already = savedTrips.find(t => t.title === destination && t.days === days);
        if (already) return; // don't duplicate
        setSavedTrips(prev => [{
            id: Date.now(), title: destination, days, budget: effectiveBudget,
            preferences, itinerary,
            savedAt: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
            gradient: GRADIENTS[Math.floor(Math.random() * GRADIENTS.length)],
        }, ...prev]);
    };

    const deleteTrip = id => setSavedTrips(prev => prev.filter(t => t.id !== id));

    const loadTrip = trip => {
        setDestination(trip.title); setDays(trip.days);
        setPreferences(trip.preferences || '');
        setItinerary(trip.itinerary); setItinDestination(trip.title);
        setCurrentPage('home');
        setTimeout(() => outputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 150);
    };

    const generateItinerary = async (e) => {
        e.preventDefault();
        if (!destination.trim()) { setError('Please enter a destination.'); return; }
        setLoading(true); setError(''); setItinerary(''); setItinDestination(destination);

        try {
            const { GoogleGenAI } = await import('@google/genai');
            const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY });

            const prompt = `Create a detailed ${days}-day travel itinerary for ${destination}.

Budget: ${effectiveBudget}
Preferences: ${preferences || 'General sightseeing and local experiences'}

STRICT FORMATTING RULES:
1. Day headings: "## Day 1: [Theme Name]"  (exactly this format)
2. Each attraction or stop: "### [Place Name]"  (short title only, no extra text)
3. Under each ###, write 2-3 plain bullet points (- ) with plain text — NO asterisks ** inside bullets
4. End with "## Budget Breakdown" section with items like "- Accommodation: ₹800-1500/night"
5. Give each day EXACTLY 5-6 places/stops spread across morning, afternoon and evening
6. NEVER use **bold** inside bullet points or descriptions — plain text only
7. Include a mix of: sightseeing, food spots, local experiences, and one hotel/stay recommendation per day`;

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: {
                    systemInstruction: 'You are an expert local travel guide. Use only clean markdown: ## for day headings, ### for place names, and - bullet points with plain text. Absolutely no ** asterisks inside descriptions.',
                    temperature: 0.7,
                },
            });
            setItinerary(response.text);
            setTimeout(() => outputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 200);
        } catch (err) {
            console.error(err);
            setError('Failed to generate itinerary. Please check your API key and try again.');
        } finally {
            setLoading(false);
        }
    };

    // ── RENDER ────────────────────────────────────────────────────────────────
    return (
        <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: 'var(--sand)' }}>

            {/* NAV */}
            <nav className="tp-nav">
                <button className="tp-logo" onClick={() => setCurrentPage('home')}>
                    <VoyageAILogo size={34} />
                    <span className="tp-logo-text">Voyage<span>AI</span></span>
                </button>
                <div className="tp-nav-links">
                    <button className={`tp-nav-link ${currentPage === 'home' ? 'active' : ''}`} onClick={() => setCurrentPage('home')}>Plan a Trip</button>
                    {isLoggedIn && (
                        <button className={`tp-nav-link ${currentPage === 'dashboard' ? 'active' : ''}`} onClick={() => setCurrentPage('dashboard')}>
                            My Trips
                            {savedTrips.length > 0 && <span style={{ background: 'var(--terra)', color: '#fff', borderRadius: 100, fontSize: '.7rem', padding: '1px 7px', marginLeft: 4 }}>{savedTrips.length}</span>}
                        </button>
                    )}
                    {isLoggedIn ? (
                        <>
                            <span style={{ fontSize: '.8rem', color: 'rgba(255,255,255,.55)', marginLeft: 4 }}>Hi, {userName || 'Explorer'}</span>
                            <button className="tp-btn-outline" onClick={handleLogout} style={{ marginLeft: 6 }}>Sign out</button>
                        </>
                    ) : (
                        <>
                            <button className="tp-btn-outline" onClick={() => setCurrentPage('login')}>Log in</button>
                            <button className="tp-btn-primary" onClick={() => setCurrentPage('signup')}>Sign up free</button>
                        </>
                    )}
                </div>
            </nav>

            {/* ── HOME ── */}
            {currentPage === 'home' && (
                <>
                    <div className="tp-hero">
                        <div className="tp-hero-badge fade-up">✦ Powered by Gemini AI</div>
                        <h1 className="fade-up fade-up-d1">Plan your dream trip<br /><em>in seconds, not hours</em></h1>
                        <p className="fade-up fade-up-d2">Tell us where you're headed and we'll craft a personalised day-by-day itinerary — hotels, food, transport and all.</p>
                    </div>

                    <main className="tp-main">
                        {/* SETTINGS CARD — compact horizontal bar */}
                        <div className="tp-card fade-up fade-up-d3">
                            <div className="tp-card-header">
                                <div className="tp-card-icon terra">🗺️</div>
                                <span className="tp-card-title">Trip Settings</span>
                            </div>

                            <form onSubmit={generateItinerary}>
                                <div className="tp-settings-row">
                                    <div className="tp-field">
                                        <label className="tp-label">Destination</label>
                                        <div className="tp-input-icon-wrap">
                                            <span className="tp-input-icon">📍</span>
                                            <input className="tp-input" type="text" placeholder="e.g. Goa, Sasan Gir, Udaipur, Paris…" value={destination} onChange={e => setDestination(e.target.value)} />
                                        </div>
                                    </div>
                                    <div className="tp-field">
                                        <label className="tp-label">Budget</label>
                                        <select className="tp-select" value={budgetType} onChange={e => setBudgetType(e.target.value)}>
                                            <option value="Budget">🎒 Backpacker</option>
                                            <option value="Mid-range">😊 Mid-Range</option>
                                            <option value="Luxury">✨ Luxury</option>
                                            <option value="Custom">✏️ Custom</option>
                                        </select>
                                    </div>
                                    <div className="tp-field">
                                        <label className="tp-label">Days</label>
                                        <input className="tp-input" type="number" min="1" max="14" value={days} onChange={e => setDays(e.target.value)} />
                                    </div>
                                    <div className="tp-field">
                                        <label className="tp-label" style={{ visibility: 'hidden' }}>Go</label>
                                        <button type="submit" className="tp-generate-btn" disabled={loading} style={{ width: '100%' }}>
                                            {loading ? <><span className="tp-spinner" style={{ width: 18, height: 18, borderWidth: 2 }} />Working…</> : '✦ Generate'}
                                        </button>
                                    </div>
                                </div>

                                {budgetType === 'Custom' && (
                                    <div style={{ marginBottom: '1rem' }}>
                                        <label className="tp-label">Your Budget (e.g. ₹20,000 for 2 people · $500 total)</label>
                                        <input className="tp-input" type="text" placeholder="Type your budget here…" value={customBudget} onChange={e => setCustomBudget(e.target.value)} />
                                    </div>
                                )}

                                <div style={{ marginTop: '.75rem' }}>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
                                        <label className="tp-label" style={{ margin: 0 }}>Preferences</label>
                                        <button type="button" className="tp-tag-btn" onClick={handleSetGujaratiCulture}>+ Gujarati Culture</button>
                                    </div>
                                    <textarea className="tp-textarea" rows={2} placeholder="e.g. historic monuments, street food, nature hikes, photography spots, water sports…" value={preferences} onChange={e => setPreferences(e.target.value)} />
                                </div>

                                {itinerary && (
                                    <button type="button" className="tp-save-btn" style={{ width: '100%', marginTop: '.75rem', justifyContent: 'center' }} onClick={saveTrip}>
                                        ✓ Save This Trip
                                    </button>
                                )}
                            </form>
                        </div>

                        {/* OUTPUT — full width below */}
                        <div className="tp-output-panel" ref={outputRef}>
                            {error && <div className="tp-error"><span>⚠️</span><span>{error}</span></div>}

                            {loading && (
                                <div className="tp-card tp-loading">
                                    <div className="tp-spinner" />
                                    <p style={{ color: 'var(--ink-soft)', fontWeight: 500 }}>Consulting local experts &amp; mapping your journey…</p>
                                    <div style={{ width: '60%' }}>
                                        {[100, 80, 90, 65].map((w, i) => (
                                            <div key={i} className="tp-shimmer-line" style={{ width: `${w}%`, animationDelay: `${i * 0.15}s` }} />
                                        ))}
                                    </div>
                                </div>
                            )}

                            {itinerary && !loading && (
                                <>
                                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
                                        <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: '1.4rem', fontWeight: 700, color: 'var(--ink)' }}>
                                            Your Itinerary — <em style={{ color: 'var(--terra)', fontStyle: 'normal' }}>{itinDestination}</em>
                                        </h2>
                                        <span className="tp-ready-badge">
                                            <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--success)', display: 'inline-block' }} />
                                            Ready
                                        </span>
                                    </div>
                                    <ItineraryDisplay raw={itinerary} destination={itinDestination} />
                                </>
                            )}

                            {!itinerary && !loading && !error && (
                                <div className="tp-card tp-output-empty">
                                    <div className="tp-output-empty-icon">🧭</div>
                                    <p>
                                        <strong style={{ color: 'var(--ink)', display: 'block', marginBottom: 6 }}>Your itinerary will appear here</strong>
                                        Fill in the settings above and hit <em>Generate</em> — your plan will show up as rich cards with photos, tags, and a budget breakdown.
                                    </p>
                                </div>
                            )}
                        </div>
                    </main>
                </>
            )}

            {/* ── LOGIN ── */}
            {currentPage === 'login' && (
                <div className="tp-auth-wrap">
                    <div className="tp-auth-card fade-up">
                        <div className="tp-auth-logo-wrap"><VoyageAILogo size={40} /></div>
                        <h2 className="tp-auth-title">Welcome back</h2>
                        <p className="tp-auth-sub">Sign in to access your saved trips.</p>
                        <form onSubmit={e => handleAuthSubmit(e, 'login')}>
                            <div className="tp-auth-field">
                                <label className="tp-label">Email</label>
                                <input className="tp-input" type="email" required placeholder="you@example.com"
                                    onChange={e => { setUserEmail(e.target.value); loginEmailRef.current = e.target.value; }} />
                            </div>
                            <div className="tp-auth-field" style={{ marginBottom: '1.5rem' }}>
                                <label className="tp-label">Password</label>
                                <input className="tp-input" type="password" required placeholder="••••••••" />
                            </div>
                            <button type="submit" className="tp-auth-btn">Sign in</button>
                        </form>
                        <p style={{ textAlign: 'center', marginTop: '1.25rem', fontSize: '.88rem', color: 'var(--ink-soft)' }}>
                            Don't have an account? <span className="tp-auth-link" onClick={() => setCurrentPage('signup')}>Create one free</span>
                        </p>
                    </div>
                </div>
            )}

            {/* ── SIGNUP ── */}
            {currentPage === 'signup' && (
                <div className="tp-auth-wrap">
                    <div className="tp-auth-card fade-up">
                        <div className="tp-auth-logo-wrap"><VoyageAILogo size={40} /></div>
                        <h2 className="tp-auth-title">Start exploring</h2>
                        <p className="tp-auth-sub">Create your free VoyageAI account.</p>
                        <form onSubmit={e => handleAuthSubmit(e, 'signup')}>
                            <div className="tp-auth-field">
                                <label className="tp-label">Full Name</label>
                                <input className="tp-input" type="text" required placeholder="John Doe"
                                    onChange={e => { signupNameRef.current = e.target.value; }} />
                            </div>
                            <div className="tp-auth-field">
                                <label className="tp-label">Email</label>
                                <input className="tp-input" type="email" required placeholder="you@example.com" onChange={e => setUserEmail(e.target.value)} />
                            </div>
                            <div className="tp-auth-field" style={{ marginBottom: '1.5rem' }}>
                                <label className="tp-label">Password</label>
                                <input className="tp-input" type="password" required placeholder="••••••••" />
                            </div>
                            <button type="submit" className="tp-auth-btn terra">Create free account</button>
                        </form>
                        <p style={{ textAlign: 'center', marginTop: '1.25rem', fontSize: '.88rem', color: 'var(--ink-soft)' }}>
                            Already have an account? <span className="tp-auth-link" onClick={() => setCurrentPage('login')}>Sign in</span>
                        </p>
                    </div>
                </div>
            )}

            {/* ── DASHBOARD ── */}
            {currentPage === 'dashboard' && (
                <main className="tp-main fade-up">
                    <div className="tp-dash-header">
                        <div>
                            <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: '1.75rem', fontWeight: 700, color: 'var(--ink)', marginBottom: 4 }}>My Trips</h2>
                            <p style={{ color: 'var(--ink-soft)', fontSize: '.9rem' }}>Your saved itineraries, ready to open any time.</p>
                        </div>
                        <button className="tp-btn-primary" style={{ padding: '10px 20px', borderRadius: 10, fontSize: '.9rem' }} onClick={() => setCurrentPage('home')}>+ Plan New Trip</button>
                    </div>

                    <div className="tp-stat-grid">
                        {[
                            { label: 'Saved Trips', value: savedTrips.length, cls: 'c1' },
                            { label: 'Days Planned', value: savedTrips.reduce((a, t) => a + (parseInt(t.days) || 0), 0), cls: 'c2' },
                            { label: 'Destinations', value: new Set(savedTrips.map(t => t.title)).size, cls: 'c3' },
                            { label: 'This Month', value: savedTrips.filter(t => t.savedAt?.includes(new Date().toLocaleString('en-IN', { month: 'short' }))).length, cls: 'c4' },
                        ].map(s => (
                            <div className={`tp-stat-card ${s.cls}`} key={s.label}>
                                <div className="tp-stat-label">{s.label}</div>
                                <div className="tp-stat-value">{s.value}</div>
                            </div>
                        ))}
                    </div>

                    {savedTrips.length === 0 ? (
                        <div style={{ textAlign: 'center', padding: '3rem 1rem', color: 'var(--ink-soft)' }}>
                            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🧭</div>
                            <p style={{ fontWeight: 500, color: 'var(--ink-mid)', marginBottom: 8 }}>No saved trips yet</p>
                            <p style={{ fontSize: '.88rem' }}>Generate an itinerary and click "Save Trip" to see it here.</p>
                            <button className="tp-btn-primary" style={{ marginTop: '1.25rem', padding: '10px 24px', borderRadius: 10 }} onClick={() => setCurrentPage('home')}>Plan your first trip →</button>
                        </div>
                    ) : (
                        <>
                            <h3 style={{ fontFamily: "'Playfair Display',serif", fontSize: '1.1rem', fontWeight: 700, color: 'var(--ink-mid)', marginBottom: '1rem' }}>Saved Itineraries</h3>
                            <div className="tp-trip-grid">
                                {savedTrips.map(trip => (
                                    <div className="tp-trip-card" key={trip.id}>
                                        <div className="tp-trip-banner" style={{ background: trip.gradient }}>
                                            <span className="tp-trip-banner-title">{trip.title}</span>
                                            <span className="tp-trip-badge">{trip.days} Days</span>
                                        </div>
                                        <div className="tp-trip-body">
                                            <div className="tp-trip-meta">🗓 Saved {trip.savedAt} · {trip.budget}</div>
                                            {trip.preferences && <p className="tp-trip-desc">{trip.preferences.slice(0, 90)}{trip.preferences.length > 90 ? '…' : ''}</p>}
                                            <button className="tp-trip-open-btn" onClick={() => loadTrip(trip)}>Open Itinerary →</button>
                                            <button className="tp-trip-del-btn" onClick={() => deleteTrip(trip.id)}>🗑 Delete</button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </>
                    )}
                </main>
            )}

            <footer className="tp-footer">
                © 2026 <strong>VoyageAI</strong> · Built with React &amp; Google Gemini · <span style={{ color: 'var(--sky-mid)' }}>Plan smarter. Travel better.</span>
            </footer>
        </div>
    );
}