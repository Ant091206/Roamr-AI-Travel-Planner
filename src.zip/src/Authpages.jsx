import React, { useRef } from 'react';
import { Logo } from './shared.jsx';

function AuthCard({ children }) {
    return (
        <div style={{ minHeight: 'calc(100vh - 64px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem', background: 'radial-gradient(ellipse at 55% 35%,var(--sky-light) 0%,var(--sand) 65%)' }}>
            <div style={{ background: 'var(--white)', borderRadius: 20, border: '1px solid var(--sand-dark)', padding: '2.5rem', width: '100%', maxWidth: 420, boxShadow: 'var(--shadow-lg)' }} className="fade-up">
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1.75rem' }}>
                    <Logo size={42} />
                </div>
                {children}
            </div>
        </div>
    );
}

export function LoginPage({ setPage, onLogin }) {
    const emailRef = useRef('');
    const passRef = useRef('');

    const handleSubmit = (e) => {
        e.preventDefault();
        const email = emailRef.current;
        const raw = email.split('@')[0].split(/[._\-+]/)[0];
        const firstName = raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase();
        onLogin(firstName || 'Explorer', email);
    };

    return (
        <AuthCard>
            <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: '1.6rem', fontWeight: 700, color: 'var(--ink)', textAlign: 'center', marginBottom: 6 }}>Welcome back</h2>
            <p style={{ textAlign: 'center', fontSize: '.9rem', color: 'var(--ink-soft)', marginBottom: '2rem' }}>Sign in to access your saved trips.</p>

            <form onSubmit={handleSubmit}>
                <div className="field">
                    <label className="label">Email Address</label>
                    <input className="input" type="email" required placeholder="you@example.com"
                        onChange={e => { emailRef.current = e.target.value; }} />
                </div>
                <div className="field" style={{ marginBottom: '1.5rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                        <label className="label" style={{ margin: 0 }}>Password</label>
                        <span style={{ fontSize: '.8rem', color: 'var(--sky-mid)', cursor: 'pointer', fontWeight: 500 }}>Forgot?</span>
                    </div>
                    <input className="input" type="password" required placeholder="••••••••"
                        onChange={e => { passRef.current = e.target.value; }} />
                </div>
                <button type="submit" className="btn btn-primary btn-md" style={{ width: '100%', justifyContent: 'center' }}>
                    Sign in →
                </button>
            </form>

            <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '1.25rem 0' }}>
                <div style={{ flex: 1, height: 1, background: 'var(--sand-dark)' }} />
                <span style={{ fontSize: '.8rem', color: 'var(--ink-soft)' }}>or continue with</span>
                <div style={{ flex: 1, height: 1, background: 'var(--sand-dark)' }} />
            </div>

            <button className="btn btn-sm" style={{ width: '100%', background: 'var(--sand)', border: '1.5px solid var(--sand-dark)', color: 'var(--ink)', justifyContent: 'center', fontWeight: 500 }}>
                <span>🔍</span> Continue with Google
            </button>

            <p style={{ textAlign: 'center', marginTop: '1.5rem', fontSize: '.88rem', color: 'var(--ink-soft)' }}>
                Don't have an account?{' '}
                <span style={{ color: 'var(--sky-mid)', fontWeight: 600, cursor: 'pointer' }} onClick={() => setPage('signup')}>Create one free</span>
            </p>
        </AuthCard>
    );
}

export function SignupPage({ setPage, onLogin }) {
    const nameRef = useRef('');
    const emailRef = useRef('');

    const handleSubmit = (e) => {
        e.preventDefault();
        const firstName = nameRef.current.trim().split(/\s+/)[0] || 'Explorer';
        const capitalized = firstName.charAt(0).toUpperCase() + firstName.slice(1);
        onLogin(capitalized, emailRef.current);
    };

    return (
        <AuthCard>
            <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: '1.6rem', fontWeight: 700, color: 'var(--ink)', textAlign: 'center', marginBottom: 6 }}>Start exploring</h2>
            <p style={{ textAlign: 'center', fontSize: '.9rem', color: 'var(--ink-soft)', marginBottom: '2rem' }}>Create your free VoyageAI account.</p>

            <form onSubmit={handleSubmit}>
                <div className="field">
                    <label className="label">Full Name</label>
                    <input className="input" type="text" required placeholder="John Doe"
                        onChange={e => { nameRef.current = e.target.value; }} />
                </div>
                <div className="field">
                    <label className="label">Email Address</label>
                    <input className="input" type="email" required placeholder="you@example.com"
                        onChange={e => { emailRef.current = e.target.value; }} />
                </div>
                <div className="field" style={{ marginBottom: '1.5rem' }}>
                    <label className="label">Password</label>
                    <input className="input" type="password" required placeholder="Min. 8 characters" />
                </div>
                <button type="submit" className="btn btn-terra btn-md" style={{ width: '100%', justifyContent: 'center' }}>
                    Create Free Account →
                </button>
            </form>

            <p style={{ textAlign: 'center', fontSize: '.78rem', color: 'var(--ink-soft)', marginTop: '1rem', lineHeight: 1.6 }}>
                By signing up you agree to our{' '}
                <span style={{ color: 'var(--sky-mid)', cursor: 'pointer' }}>Terms of Service</span>
                {' '}and{' '}
                <span style={{ color: 'var(--sky-mid)', cursor: 'pointer' }}>Privacy Policy</span>.
            </p>

            <p style={{ textAlign: 'center', marginTop: '1.25rem', fontSize: '.88rem', color: 'var(--ink-soft)' }}>
                Already have an account?{' '}
                <span style={{ color: 'var(--sky-mid)', fontWeight: 600, cursor: 'pointer' }} onClick={() => setPage('login')}>Sign in</span>
            </p>
        </AuthCard>
    );
}